# Pepsi Client 1.8.9

A client-side utility mod for Minecraft 1.8.9 using Forge 11.15.1.2318.

## Included features

- Right Shift opens the draggable ClickGUI
- Category navigation and module toggles
- HUD branding and enabled-module list
- FPS and XYZ coordinate overlays
- FullBright (restores the previous gamma value when disabled)
- Sprint (automatically sprints while moving forward)
- Module enabled states and keybinds saved to `config/pepsiclient.json`

## Build requirements

- Java 8 (recommended for this legacy ForgeGradle toolchain)
- Gradle 2.7-compatible environment / ForgeGradle 2.1
- Internet access for the first dependency setup

From the project directory, run:

```bash
gradle setupDecompWorkspace
gradle build
```

The compiled mod should be written to `build/libs/`. This source package does not include a Gradle wrapper.

## Install

Copy the built `PepsiClient-1.0.0.jar` into the Minecraft 1.8.9 `mods` folder alongside a compatible Forge 1.8.9 installation.

## Notes

This project targets the legacy Minecraft 1.8.9 Forge API. It has been source-reviewed and patched, but it has **not** been compiled or launched in a Minecraft runtime in this environment. Use Java 8 and the legacy-compatible Gradle toolchain; modern Java/Gradle versions may not work with ForgeGradle 2.1.
