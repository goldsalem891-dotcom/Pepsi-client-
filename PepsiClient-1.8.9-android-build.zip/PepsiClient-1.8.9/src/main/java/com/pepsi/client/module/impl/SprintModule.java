package com.pepsi.client.module.impl;

import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;

public class SprintModule extends Module {
    public SprintModule() { super("Sprint", Category.MOVEMENT, 0); }

    @Override
    public void onUpdate() {
        if (mc.thePlayer != null && mc.thePlayer.moveForward > 0.0F) {
            mc.thePlayer.setSprinting(true);
        }
    }
}
