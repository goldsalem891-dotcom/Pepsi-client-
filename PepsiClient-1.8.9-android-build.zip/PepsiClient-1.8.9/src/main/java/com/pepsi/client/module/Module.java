package com.pepsi.client.module;

import net.minecraft.client.Minecraft;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    private final String name;
    private final Category category;
    private final int defaultKey;
    private int key;
    private boolean enabled;

    protected Module(String name, Category category, int key) {
        this.name = name;
        this.category = category;
        this.defaultKey = key;
        this.key = key;
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (enabled) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onUpdate() {}

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public int getDefaultKey() { return defaultKey; }
    public boolean isEnabled() { return enabled; }
}
