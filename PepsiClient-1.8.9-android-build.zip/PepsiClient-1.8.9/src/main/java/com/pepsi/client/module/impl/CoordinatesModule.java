package com.pepsi.client.module.impl;

import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;

public class CoordinatesModule extends Module {
    public CoordinatesModule() { super("Coordinates", Category.HUD, 0); }
    @Override public void onEnable() { MinecraftForge.EVENT_BUS.register(this); }
    @Override public void onDisable() { MinecraftForge.EVENT_BUS.unregister(this); }

    @SubscribeEvent
    public void render(RenderGameOverlayEvent.Text event) {
        if (mc.thePlayer == null) return;
        String text = String.format("XYZ: %.1f / %.1f / %.1f",
            mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        mc.fontRendererObj.drawStringWithShadow(text, 5, 30, 0xFFFFFFFF);
    }
}
