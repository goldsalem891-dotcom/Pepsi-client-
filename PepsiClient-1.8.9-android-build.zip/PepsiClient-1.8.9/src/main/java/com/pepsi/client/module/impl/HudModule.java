package com.pepsi.client.module.impl;

import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;

public class HudModule extends Module {
    public HudModule() { super("HUD", Category.HUD, 0); }

    @Override
    public void onEnable() { MinecraftForge.EVENT_BUS.register(this); }

    @Override
    public void onDisable() { MinecraftForge.EVENT_BUS.unregister(this); }

    @SubscribeEvent
    public void render(RenderGameOverlayEvent.Text event) {
        mc.fontRendererObj.drawStringWithShadow("PEPSI CLIENT", 5, 5, 0xFF35D9FF);
        int y = 17;
        for (com.pepsi.client.module.Module module :
                com.pepsi.client.module.ModuleManager.getModules()) {
            if (module.isEnabled() && module != this) {
                mc.fontRendererObj.drawStringWithShadow(module.getName(), 5, y, 0xFFFFFFFF);
                y += 11;
            }
        }
    }
}
