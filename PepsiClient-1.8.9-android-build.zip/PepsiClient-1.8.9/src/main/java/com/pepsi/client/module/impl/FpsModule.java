package com.pepsi.client.module.impl;

import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;

public class FpsModule extends Module {
    public FpsModule() { super("FPS", Category.HUD, 0); }
    @Override public void onEnable() { MinecraftForge.EVENT_BUS.register(this); }
    @Override public void onDisable() { MinecraftForge.EVENT_BUS.unregister(this); }

    @SubscribeEvent
    public void render(RenderGameOverlayEvent.Text event) {
        mc.fontRendererObj.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(),
            5, 43, 0xFFFFFFFF);
    }
}
