package com.pepsi.client.module.impl;

import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;

public class FullBrightModule extends Module {
    private float oldGamma;

    public FullBrightModule() { super("FullBright", Category.RENDER, 0); }

    @Override
    public void onEnable() {
        oldGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 100.0F;
    }

    @Override
    public void onDisable() {
        mc.gameSettings.gammaSetting = oldGamma;
    }
}
