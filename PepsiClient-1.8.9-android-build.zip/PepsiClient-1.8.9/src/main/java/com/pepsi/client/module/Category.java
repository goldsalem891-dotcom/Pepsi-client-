package com.pepsi.client.module;

public enum Category {
    COMBAT, MOVEMENT, PLAYER, RENDER, WORLD, HUD, MISC
}
