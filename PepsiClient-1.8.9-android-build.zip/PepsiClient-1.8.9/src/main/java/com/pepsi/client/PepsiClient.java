package com.pepsi.client;

import com.pepsi.client.config.ConfigManager;
import com.pepsi.client.module.ModuleManager;
import com.pepsi.client.module.impl.ClickGuiModule;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = PepsiClient.MOD_ID, name = "Pepsi Client", version = "1.0.0", clientSideOnly = true)
public class PepsiClient {
    public static final String MOD_ID = "pepsiclient";
    public static final Minecraft MC = Minecraft.getMinecraft();

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModuleManager.init();
        ConfigManager.load();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(ModuleManager.INSTANCE);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKeyState()) {
            ModuleManager.onKey(Keyboard.getEventKey());
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            ModuleManager.onTick();
        }
    }
}
