package com.pepsi.client.module.impl;

import com.pepsi.client.gui.ClickGui;
import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;
import org.lwjgl.input.Keyboard;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", Category.RENDER, Keyboard.KEY_RSHIFT);
    }

    @Override
    public void onEnable() {
        if (mc.theWorld != null) mc.displayGuiScreen(new ClickGui());
        setEnabled(false);
    }
}
