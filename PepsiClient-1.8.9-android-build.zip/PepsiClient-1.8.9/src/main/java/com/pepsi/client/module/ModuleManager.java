package com.pepsi.client.module;

import com.pepsi.client.module.impl.*;
import com.pepsi.client.config.ConfigManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ModuleManager {
    public static final ModuleManager INSTANCE = new ModuleManager();
    private static final List<Module> MODULES = new ArrayList<Module>();

    public static void init() {
        MODULES.clear();
        MODULES.add(new ClickGuiModule());
        MODULES.add(new HudModule());
        MODULES.add(new FullBrightModule());
        MODULES.add(new SprintModule());
        MODULES.add(new CoordinatesModule());
        MODULES.add(new FpsModule());
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static Module get(String name) {
        for (Module module : MODULES) {
            if (module.getName().equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public static void onKey(int key) {
        if (key == 0) return;
        for (Module module : MODULES) {
            if (module.getKey() == key) {
                module.toggle();
                ConfigManager.save();
            }
        }
    }

    public static void onTick() {
        for (Module module : MODULES) {
            if (module.isEnabled()) module.onUpdate();
        }
    }
}
