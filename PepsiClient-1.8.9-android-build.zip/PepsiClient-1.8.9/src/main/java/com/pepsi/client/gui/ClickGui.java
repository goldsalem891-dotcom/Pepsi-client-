package com.pepsi.client.gui;

import com.pepsi.client.config.ConfigManager;
import com.pepsi.client.module.Category;
import com.pepsi.client.module.Module;
import com.pepsi.client.module.ModuleManager;
import java.io.IOException;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

public class ClickGui extends GuiScreen {
    private Category selected = Category.RENDER;
    private int panelX = 45, panelY = 35;
    private boolean dragging;
    private int dragX, dragY;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int width = 430, height = 330;
        Gui.drawRect(panelX, panelY, panelX + width, panelY + height, 0xEE10141D);
        Gui.drawRect(panelX, panelY, panelX + width, panelY + 27, 0xFF172638);
        drawString(fontRendererObj, "PEPSI CLIENT  |  1.8.9", panelX + 10, panelY + 9, 0xFF35D9FF);

        int catY = panelY + 40;
        for (Category category : Category.values()) {
            int color = category == selected ? 0xFF35D9FF : 0xFFCCCCCC;
            drawString(fontRendererObj, category.name(), panelX + 12, catY, color);
            catY += 22;
        }

        int x = panelX + 125, y = panelY + 42;
        for (Module module : ModuleManager.getModules()) {
            if (module.getCategory() != selected) continue;
            Gui.drawRect(x, y - 3, x + 285, y + 15,
                module.isEnabled() ? 0xFF164C58 : 0xFF242C38);
            drawString(fontRendererObj, module.getName(), x + 7, y, 0xFFFFFFFF);
            drawString(fontRendererObj, module.isEnabled() ? "ON" : "OFF",
                x + 250, y, module.isEnabled() ? 0xFF55FF99 : 0xFFAAAAAA);
            y += 23;
        }
        drawString(fontRendererObj, "Click a module to toggle | Right Shift closes",
            panelX + 10, panelY + height - 18, 0xFF999999);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button == 0 && mouseY >= panelY && mouseY <= panelY + 27
                && mouseX >= panelX && mouseX <= panelX + 430) {
            dragging = true; dragX = mouseX - panelX; dragY = mouseY - panelY;
            return;
        }
        if (button == 0) {
            int cy = panelY + 40;
            for (Category category : Category.values()) {
                if (mouseX >= panelX + 8 && mouseX <= panelX + 112
                        && mouseY >= cy - 4 && mouseY <= cy + 13) {
                    selected = category;
                    return;
                }
                cy += 22;
            }
            int y = panelY + 42;
            for (Module module : ModuleManager.getModules()) {
                if (module.getCategory() != selected) continue;
                if (mouseX >= panelX + 125 && mouseX <= panelX + 410
                        && mouseY >= y - 3 && mouseY <= y + 15) {
                    module.toggle();
                    ConfigManager.save();
                    return;
                }
                y += 23;
            }
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long elapsed) {
        if (dragging) { panelX = mouseX - dragX; panelY = mouseY - dragY; }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_RSHIFT) {
            mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
