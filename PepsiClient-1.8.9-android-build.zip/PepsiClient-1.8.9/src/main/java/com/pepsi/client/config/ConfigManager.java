package com.pepsi.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pepsi.client.module.Module;
import com.pepsi.client.module.ModuleManager;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import com.pepsi.client.PepsiClient;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File FILE = new File(PepsiClient.MC.mcDataDir, "config/pepsiclient.json");

    public static void save() {
        try {
            File parent = FILE.getParentFile();
            if (!parent.exists()) parent.mkdirs();
            JsonObject root = new JsonObject();
            for (Module module : ModuleManager.getModules()) {
                JsonObject item = new JsonObject();
                item.addProperty("enabled", module.isEnabled());
                item.addProperty("key", module.getKey());
                root.add(module.getName(), item);
            }
            try (FileWriter writer = new FileWriter(FILE)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void load() {
        if (!FILE.isFile()) return;
        try {
            try (FileReader reader = new FileReader(FILE)) {
                JsonObject root = new JsonParser().parse(reader).getAsJsonObject();
                for (Module module : ModuleManager.getModules()) {
                    if (!root.has(module.getName()) || !root.get(module.getName()).isJsonObject()) continue;
                    JsonObject item = root.getAsJsonObject(module.getName());
                    if (item.has("key") && item.get("key").isJsonPrimitive()) {
                        module.setKey(item.get("key").getAsInt());
                    }
                    if (item.has("enabled") && item.get("enabled").isJsonPrimitive()) {
                        module.setEnabled(item.get("enabled").getAsBoolean());
                    }
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private ConfigManager() {}
}
