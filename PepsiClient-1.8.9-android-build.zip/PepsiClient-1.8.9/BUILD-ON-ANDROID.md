# Build Pepsi Client 1.8.9 from an Android phone (Zalith Launcher 2)

This project is source code. It is not yet a ready-to-install Forge mod JAR.
The included GitHub Actions workflow builds it in the cloud using Java 8 and
Gradle 2.14.1, which are appropriate starting points for this legacy
ForgeGradle 2.1 project.

## Build from Android

1. In Chrome, sign in to GitHub and create a **public** repository named
   `PepsiClient` (public repositories can use GitHub Actions without spending
   private-repository minutes, subject to GitHub's current limits).
2. Extract this ZIP on your phone. Upload the *contents* of the
   `PepsiClient-1.8.9` folder to the repository root. Make sure `.github` is
   included; Android file pickers sometimes hide dot-folders. If necessary,
   enable hidden files in your file manager.
3. In the repository, open **Actions** and select **Build Pepsi Client 1.8.9**.
4. Tap **Run workflow** and confirm. Wait for the run to finish with a green
   check mark. If it fails, open the run and inspect the first red error step.
5. Open the successful run, scroll to **Artifacts**, and download
   `PepsiClient-1.8.9`. Extract the artifact ZIP; it should contain the built
   `PepsiClient-1.0.0.jar`.

## Install into Zalith Launcher 2

1. In Zalith 2, install and launch **Minecraft 1.8.9 with Forge 11.15.1.2318**
   once, then close the game.
2. Open the instance's game directory from its instance/settings page. Use the
   instance-specific `.minecraft` directory, not a different profile's folder.
3. Open or create `mods` inside that game directory.
4. Copy `PepsiClient-1.0.0.jar` into `mods`.
5. Start that same Forge 1.8.9 instance. Check the Mods list for **Pepsi Client**.

If it crashes, remove the Pepsi JAR from `mods` and share the crash report or
`logs/latest.log`. Do not put the source ZIP or source JAR in `mods`.

## Important

The workflow is a build attempt, not a claim that this source has already been
successfully compiled or tested in Zalith. ForgeGradle 2.1 is very old, and
remote dependency or compatibility issues may still need fixing. The mod uses
Forge 1.8.9 APIs and is not guaranteed to work with every launcher build.
